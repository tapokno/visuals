package com.visualplayer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Очередь слов, тайминги, пауза, скорость. Время считается в миллисекундах. */
public final class PlayerState {
    public static final PlayerState INSTANCE = new PlayerState();

    public record Word(String text, Effect effect) {}

    private static final Pattern TAG = Pattern.compile("^\\{([\\p{L}\\w]+)}(.*)$");
    public static final double OUTRO_MS = 1500;
    public static final double INTRO_MS = 250;

    private final List<Word> words = new ArrayList<>();
    private int index;
    private double elapsed;      // мс внутри текущего слова
    private double clock;        // глобальные часы для анимаций (идут всегда)
    private double sinceStart;   // для появления панели
    private double outro;        // для исчезновения после конца
    private long lastNanos = -1;
    private boolean active, paused, finished;
    private boolean visible = true;
    private float speed = 1f;
    private String lastText = "";

    /**
     * Загружает текст. Теги вида {wave} меняют эффект для следующих слов,
     * можно и слитно: {rainbow}привет
     */
    public int load(String raw, Effect defaultEffect) {
        words.clear();
        lastText = raw;
        Effect current = defaultEffect;
        int i = 0;
        for (String token : raw.trim().split("\\s+")) {
            if (token.isEmpty()) continue;
            Matcher m = TAG.matcher(token);
            if (m.matches()) {
                Effect e = Effect.byName(m.group(1));
                if (e != null) current = e;
                token = m.group(2);
                if (token.isEmpty()) continue;
            }
            Effect use = current == Effect.MIX ? Effect.cycle(i) : current;
            words.add(new Word(token, use));
            i++;
        }
        index = 0;
        elapsed = 0;
        sinceStart = 0;
        outro = 0;
        paused = false;
        finished = false;
        active = !words.isEmpty();
        return words.size();
    }

    public static double duration(Word w) {
        int len = w.text().codePointCount(0, w.text().length());
        return switch (w.effect()) {
            case TYPE -> 55.0 * len + 700;
            case BOUNCE, FADE -> 45.0 * len + 750;
            default -> 500 + 70.0 * len;
        };
    }

    /** Вызывается каждый кадр из HUD. */
    public void update() {
        long now = System.nanoTime();
        if (lastNanos < 0) lastNanos = now;
        double dt = Math.min((now - lastNanos) / 1_000_000.0, 100.0);
        lastNanos = now;
        clock += dt;
        if (!active) return;
        sinceStart += dt;
        if (finished) {
            outro += dt;
            if (outro >= OUTRO_MS) active = false;
            return;
        }
        if (paused) return;
        elapsed += dt * speed;
        while (index < words.size() && elapsed >= duration(words.get(index))) {
            elapsed -= duration(words.get(index));
            index++;
        }
        if (index >= words.size()) {
            index = words.size() - 1;
            elapsed = duration(words.get(index));
            finished = true;
            outro = 0;
        }
    }

    public void stop() { active = false; words.clear(); }
    public boolean togglePause() { if (active && !finished) paused = !paused; return paused; }
    public void restart() { if (!words.isEmpty()) { index = 0; elapsed = 0; outro = 0; finished = false; paused = false; active = true; sinceStart = 0; } }

    public void setSpeed(float s) { speed = Math.max(0.25f, Math.min(4f, s)); }
    public float speed() { return speed; }
    public void setVisible(boolean v) { visible = v; }
    public boolean visible() { return visible; }
    public boolean active() { return active; }
    public boolean paused() { return paused; }
    public boolean finished() { return finished; }
    public int index() { return index; }
    public double elapsed() { return elapsed; }
    public double clock() { return clock; }
    public double sinceStart() { return sinceStart; }
    public double outro() { return outro; }
    public String lastText() { return lastText; }
    public List<Word> words() { return Collections.unmodifiableList(words); }
    public Word current() { return words.isEmpty() ? null : words.get(index); }

    public double progress() {
        if (words.isEmpty()) return 0;
        Word w = words.get(index);
        return Math.min(1.0, (index + Math.min(1.0, elapsed / duration(w))) / words.size());
    }
}
