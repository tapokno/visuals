package com.visualplayer;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Пульт управления: поле текста, выбор эффекта, кнопки плеера. */
public class PlayerScreen extends Screen {
    private static Effect selected = Effect.MIX;
    private TextFieldWidget input;

    public PlayerScreen() {
        super(Text.literal("Visual Player"));
    }

    @Override
    protected void init() {
        PlayerState st = PlayerState.INSTANCE;
        int cx = width / 2;
        int top = height / 2 - 40;

        input = new TextFieldWidget(textRenderer, cx - 150, top, 300, 20, Text.literal("Текст"));
        input.setMaxLength(2000);
        input.setText(st.lastText());
        input.setPlaceholder(Text.literal("Напиши фразу… {wave}теги тоже работают"));
        addDrawableChild(input);
        setInitialFocus(input);

        addDrawableChild(ButtonWidget.builder(effectLabel(), b -> {
            selected = selected.next();
            b.setMessage(effectLabel());
        }).dimensions(cx - 150, top + 26, 300, 20).build());

        int bw = 58, gap = 3, rowY = top + 52;
        int rowX = cx - (bw * 5 + gap * 4) / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("▶ Пуск"), b -> {
            if (!input.getText().isBlank()) st.load(input.getText(), selected);
        }).dimensions(rowX, rowY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("⏯ Пауза"), b -> st.togglePause())
                .dimensions(rowX + (bw + gap), rowY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("↺ Заново"), b -> st.restart())
                .dimensions(rowX + (bw + gap) * 2, rowY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("■ Стоп"), b -> st.stop())
                .dimensions(rowX + (bw + gap) * 3, rowY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                .dimensions(rowX + (bw + gap) * 4, rowY, bw, 20).build());

        int sy = top + 78;
        addDrawableChild(ButtonWidget.builder(Text.literal("− скорость"), b -> st.setSpeed(st.speed() - 0.25f))
                .dimensions(cx - 150, sy, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+ скорость"), b -> st.setSpeed(st.speed() + 0.25f))
                .dimensions(cx + 50, sy, 100, 20).build());
    }

    private static Text effectLabel() {
        return Text.literal("Эффект: " + selected.label + "  (нажми, чтобы сменить)");
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // без блюра, чтобы плеер наверху было видно
        ctx.fill(0, height / 2 - 62, width, height / 2 + 66, 0xA0000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, title, cx, height / 2 - 56, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Скорость: x" + PlayerState.INSTANCE.speed()), cx, height / 2 + 44, 0xFFBFC3D9);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
