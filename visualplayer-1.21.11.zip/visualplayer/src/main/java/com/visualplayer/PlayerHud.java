package com.visualplayer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.List;

import static com.visualplayer.EffectRenderer.*;

/** Панель-плеер вверху экрана. */
public final class PlayerHud {
    private static final int W = 280;
    private static final int H = 100;

    private PlayerHud() {}

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        PlayerState st = PlayerState.INSTANCE;
        st.update();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!st.visible() || !st.active() || mc.options.hudHidden) return;
        if (st.words().isEmpty()) return;

        TextRenderer tr = mc.textRenderer;
        double clock = st.clock();

        // появление / исчезновение панели
        float alpha;
        float slide;
        if (st.finished()) {
            float p = (float) clamp(st.outro() / PlayerState.OUTRO_MS, 0, 1);
            alpha = 1f - p * p;
            slide = -p * p * 12f;
        } else {
            float p = (float) clamp(st.sinceStart() / PlayerState.INTRO_MS, 0, 1);
            alpha = easeOutCubic(p);
            slide = (1f - easeOutCubic(p)) * -12f;
        }
        if (alpha <= 0.02f) return;

        int sw = ctx.getScaledWindowWidth();
        int x = (sw - W) / 2;
        int y = 6 + Math.round(slide);

        // --- фон и рамка ---
        int accent = hsv((float) (clock * 0.00012 % 1.0), 0.6f, 1f);
        ctx.fill(x - 1, y - 1, x + W + 1, y + H + 1, argb(alpha * 0.55f, accent));
        ctx.fill(x, y, x + W, y + H, argb(alpha * 0.86f, 0x0D0E14));
        ctx.fill(x, y + 14, x + W, y + 15, argb(alpha * 0.25f, 0xFFFFFF));

        // радужная полоска сверху
        int seg = 10;
        for (int sx = 0; sx < W; sx += seg) {
            int c = hsv((float) ((clock * 0.0002 + sx / (double) W) % 1.0), 0.7f, 1f);
            ctx.fill(x + sx, y, x + Math.min(W, sx + seg), y + 2, argb(alpha, c));
        }

        // --- шапка ---
        String state = st.paused() ? "II" : (st.finished() ? "■" : "▶");
        ctx.drawText(tr, state + "  VISUAL PLAYER", x + 6, y + 4, argb(alpha, 0xBFC3D9), false);

        PlayerState.Word cur = st.current();
        String fx = cur.effect().label.toUpperCase();
        int fxW = tr.getWidth(fx);
        ctx.drawText(tr, fx, x + W - 46 - fxW, y + 4, argb(alpha, accent), false);

        // эквалайзер
        for (int b = 0; b < 6; b++) {
            double phase = st.paused() || st.finished() ? 0.3 : (0.5 + 0.5 * Math.sin(clock * 0.012 * (1 + b * 0.37) + b * 1.7));
            int bh = 2 + (int) Math.round(phase * 8);
            int bx = x + W - 40 + b * 6;
            int c = hsv((float) ((clock * 0.0003 + b * 0.08) % 1.0), 0.65f, 1f);
            ctx.fill(bx, y + 12 - bh, bx + 4, y + 12, argb(alpha, c));
        }

        // --- главное слово ---
        float maxScale = 2.8f;
        int ww = Math.max(1, tr.getWidth(cur.text()));
        float scale = Math.min(maxScale, (W - 24f) / ww);
        double dur = PlayerState.duration(cur);
        double t = st.elapsed();
        // у последнего слова после конца держим его на экране до исчезновения панели
        double durForFade = st.finished() ? dur + 10_000 : dur;
        EffectRenderer.renderWord(ctx, tr, cur.text(), cur.effect(), t, durForFade, clock,
                x + W / 2f, y + 42, scale, alpha);

        // --- строка-караоке: пред / текущее / след ---
        List<PlayerState.Word> words = st.words();
        int i = st.index();
        String prev = i > 0 ? words.get(i - 1).text() : "";
        String next = i + 1 < words.size() ? words.get(i + 1).text() : "";
        String mid = cur.text();
        int gap = 8;
        int midW = tr.getWidth(mid);
        int lineY = y + 68;
        int midX = x + (W - midW) / 2;
        ctx.drawText(tr, mid, midX, lineY, argb(alpha, 0xFFFFFF), true);
        if (!prev.isEmpty()) {
            String p = ellipsize(tr, prev, (W - midW) / 2 - gap - 6, true);
            ctx.drawText(tr, p, midX - gap - tr.getWidth(p), lineY, argb(alpha * 0.45f, 0xBFC3D9), false);
        }
        if (!next.isEmpty()) {
            String n = ellipsize(tr, next, (W - midW) / 2 - gap - 6, false);
            ctx.drawText(tr, n, midX + midW + gap, lineY, argb(alpha * 0.45f, 0xBFC3D9), false);
        }

        // --- прогресс-бар ---
        int px1 = x + 8, px2 = x + W - 52, py = y + H - 12;
        ctx.fill(px1, py, px2, py + 3, argb(alpha * 0.35f, 0xFFFFFF));
        int filled = px1 + (int) Math.round((px2 - px1) * st.progress());
        for (int sx = px1; sx < filled; sx += 4) {
            int c = hsv((float) ((clock * 0.0002 + (sx - px1) / (double) (px2 - px1) * 0.6) % 1.0), 0.6f, 1f);
            ctx.fill(sx, py, Math.min(filled, sx + 4), py + 3, argb(alpha, c));
        }
        ctx.fill(filled - 2, py - 2, filled + 2, py + 5, argb(alpha, 0xFFFFFF));

        String counter = (i + 1) + "/" + words.size() + "  x" + trimSpeed(st.speed());
        ctx.drawText(tr, counter, px2 + 6, py - 2, argb(alpha, 0x9EA3B8), false);
    }

    private static String trimSpeed(float s) {
        return s == (int) s ? Integer.toString((int) s) : String.format(java.util.Locale.ROOT, "%.2f", s).replaceAll("0+$", "");
    }

    private static String ellipsize(TextRenderer tr, String s, int maxW, boolean fromLeft) {
        if (maxW <= 6) return "";
        if (tr.getWidth(s) <= maxW) return s;
        String dots = "…";
        String r = s;
        while (!r.isEmpty() && tr.getWidth(dots + r) > maxW) r = fromLeft ? r.substring(1) : r.substring(0, r.length() - 1);
        return fromLeft ? dots + r : r + dots;
    }
}
