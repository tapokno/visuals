package com.visualplayer;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

import java.util.Random;

/** Посимвольная отрисовка слова с эффектом. */
public final class EffectRenderer {
    private static final String GLITCH_CHARS = "#$%&@!?*01<>/\\=+";

    private EffectRenderer() {}

    /**
     * @param t     мс с начала показа слова
     * @param dur   полная длительность слова (мс)
     * @param clock глобальные часы (мс)
     * @param cx,cy центр слова на экране
     * @param alpha общая прозрачность 0..1
     */
    public static void renderWord(DrawContext ctx, TextRenderer tr, String word, Effect effect,
                                  double t, double dur, double clock,
                                  float cx, float cy, float scale, float alpha) {
        int[] cps = word.codePoints().toArray();
        String[] chars = new String[cps.length];
        int[] widths = new int[cps.length];
        int total = 0;
        for (int i = 0; i < cps.length; i++) {
            chars[i] = new String(Character.toChars(cps[i]));
            widths[i] = tr.getWidth(chars[i]);
            total += widths[i];
        }

        // плавное затухание в конце слова
        float out = (float) clamp((dur - t) / 140.0, 0, 1);
        float a0 = alpha * out;
        if (a0 <= 0.02f) return;

        float fh = tr.fontHeight;
        float x = cx - total * scale / 2f;
        float y = cy - fh * scale / 2f;

        int typed = (int) (t / 55.0);

        for (int i = 0; i < chars.length; i++) {
            String ch = chars[i];
            float cw = widths[i];
            float dx = 0, dy = 0, rot = 0, s = 1, a = 1;
            int rgb = 0xFFFFFF;

            switch (effect) {
                case TYPE -> {
                    if (i >= typed) { a = 0; break; }
                    rgb = (i == typed - 1 && t < 55.0 * chars.length + 80) ? 0xFFE066 : 0xF2F2F2;
                }
                case WAVE -> {
                    dy = (float) Math.sin(clock * 0.008 - i * 0.55) * 3.2f;
                    rgb = lerpColor(0x4FE3FF, 0xB46CFF, chars.length <= 1 ? 0 : (float) i / (chars.length - 1));
                }
                case RAINBOW -> {
                    rgb = hsv((float) ((clock * 0.00035 + i * 0.07) % 1.0), 0.75f, 1f);
                    dy = (float) Math.sin(clock * 0.006 + i) * 0.8f;
                }
                case SHAKE -> {
                    Random r = new Random((long) (clock / 40) * 977L + i * 13L);
                    dx = (r.nextFloat() - 0.5f) * 2.4f;
                    dy = (r.nextFloat() - 0.5f) * 2.4f;
                    rot = (r.nextFloat() - 0.5f) * 0.12f;
                    rgb = lerpColor(0xFF5A3C, 0xFFB03C, r.nextFloat());
                }
                case FADE -> {
                    double local = t - i * 40;
                    float p = (float) clamp(local / 350.0, 0, 1);
                    float e = easeOutCubic(p);
                    a = e;
                    s = 1f + (1f - e) * 1.2f;
                    dy = (1f - e) * -4f;
                    rgb = lerpColor(0x8AB6FF, 0xFFFFFF, e);
                }
                case GLITCH -> {
                    long bucket = (long) (clock / 70);
                    Random r = new Random(bucket * 31L + i * 7L);
                    boolean hot = r.nextFloat() < 0.22f;
                    if (r.nextFloat() < 0.12f) ch = String.valueOf(GLITCH_CHARS.charAt(r.nextInt(GLITCH_CHARS.length())));
                    if (hot) dx = (r.nextFloat() - 0.5f) * 3f;
                    // хроматические копии
                    drawChar(ctx, tr, ch, x + dx * scale - scale, y, cw, fh, scale, 0, argb(a0 * 0.7f, 0xFF2D55), false);
                    drawChar(ctx, tr, ch, x + dx * scale + scale, y, cw, fh, scale, 0, argb(a0 * 0.7f, 0x2DE1FF), false);
                    rgb = hot ? 0xFFFFFF : 0xE6E6E6;
                }
                case BOUNCE -> {
                    double local = t - i * 45;
                    if (local < 0) { a = 0; break; }
                    float p = (float) clamp(local / 420.0, 0, 1);
                    dy = -(1f - easeOutBounce(p)) * 14f;
                    a = (float) clamp(local / 80.0, 0, 1);
                    rgb = lerpColor(0x7CFF6B, 0x2EE6A6, (float) i / Math.max(1, chars.length - 1));
                }
                case NEON -> {
                    float pulse = 0.7f + 0.3f * (float) Math.sin(clock * 0.01 + i * 0.3);
                    int glow = 0xFF4FD8;
                    float ga = a0 * 0.28f * pulse;
                    for (int ox = -1; ox <= 1; ox++) for (int oy = -1; oy <= 1; oy++) {
                        if (ox == 0 && oy == 0) continue;
                        drawChar(ctx, tr, ch, x + ox * scale, y + oy * scale, cw, fh, scale, 0, argb(ga, glow), false);
                    }
                    rgb = lerpColor(glow, 0xFFFFFF, 0.55f * pulse);
                }
                case MIX -> { /* MIX раскрывается при загрузке */ }
            }

            float fa = a0 * a;
            if (fa > 0.02f) {
                drawChar(ctx, tr, ch, x + dx * scale, y + dy * scale, cw, fh, scale * s, rot, argb(fa, rgb), true);
            }
            x += cw * scale;
        }

        // мигающий курсор печатной машинки
        if (effect == Effect.TYPE && ((long) (clock / 300)) % 2 == 0) {
            float cxEnd = cx - total * scale / 2f;
            for (int i = 0; i < Math.min(typed, chars.length); i++) cxEnd += widths[i] * scale;
            drawChar(ctx, tr, "_", cxEnd, y, tr.getWidth("_"), fh, scale, 0, argb(a0, 0xFFE066), true);
        }
    }

    /** Рисует символ так, чтобы масштаб/поворот шли вокруг его центра. */
    static void drawChar(DrawContext ctx, TextRenderer tr, String ch, float x, float y,
                         float cw, float fh, float scale, float rot, int color, boolean shadow) {
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x + cw * scale / 2f, y + fh * scale / 2f);
        if (rot != 0) m.rotate(rot);
        m.scale(scale, scale);
        m.translate(-cw / 2f, -fh / 2f);
        ctx.drawText(tr, ch, 0, 0, color, shadow);
        m.popMatrix();
    }

    // ---------- утилиты ----------
    public static double clamp(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

    public static int argb(float a, int rgb) {
        int ai = (int) (clamp(a, 0, 1) * 255);
        return (ai << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerpColor(int c1, int c2, float t) {
        t = (float) clamp(t, 0, 1);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (r << 16) | (g << 8) | b;
    }

    public static int hsv(float h, float s, float v) {
        h = (h % 1f + 1f) % 1f;
        float c = v * s, x = c * (1 - Math.abs((h * 6) % 2 - 1)), m = v - c;
        float r, g, b;
        int sector = (int) (h * 6);
        switch (sector) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return ((int) ((r + m) * 255) << 16) | ((int) ((g + m) * 255) << 8) | (int) ((b + m) * 255);
    }

    static float easeOutCubic(float p) { float q = 1 - p; return 1 - q * q * q; }

    static float easeOutBounce(float p) {
        float n = 7.5625f, d = 2.75f;
        if (p < 1 / d) return n * p * p;
        if (p < 2 / d) { p -= 1.5f / d; return n * p * p + 0.75f; }
        if (p < 2.5 / d) { p -= 2.25f / d; return n * p * p + 0.9375f; }
        p -= 2.625f / d;
        return n * p * p + 0.984375f;
    }
}
