package com.visualplayer;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class VisualPlayerClient implements ClientModInitializer {
    public static final String MOD_ID = "visualplayer";

    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of(MOD_ID, "player"), PlayerHud::render);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(literal("vp")
                        .executes(c -> openGui(c))
                        .then(literal("gui").executes(c -> openGui(c)))
                        .then(literal("play")
                                .then(argument("text", StringArgumentType.greedyString())
                                        .executes(c -> play(c, Effect.MIX))))
                        .then(literal("fx")
                                .then(argument("effect", StringArgumentType.word())
                                        .suggests((c, b) -> {
                                            for (Effect e : Effect.values()) b.suggest(e.id);
                                            return b.buildFuture();
                                        })
                                        .then(argument("text", StringArgumentType.greedyString())
                                                .executes(c -> {
                                                    Effect e = Effect.byName(StringArgumentType.getString(c, "effect"));
                                                    if (e == null) {
                                                        c.getSource().sendError(Text.literal("Нет такого эффекта. Список: /vp effects"));
                                                        return 0;
                                                    }
                                                    return play(c, e);
                                                }))))
                        .then(literal("pause").executes(c -> {
                            boolean p = PlayerState.INSTANCE.togglePause();
                            msg(c, p ? "Пауза" : "Продолжаем");
                            return 1;
                        }))
                        .then(literal("restart").executes(c -> { PlayerState.INSTANCE.restart(); return 1; }))
                        .then(literal("stop").executes(c -> { PlayerState.INSTANCE.stop(); msg(c, "Остановлено"); return 1; }))
                        .then(literal("hide").executes(c -> { PlayerState.INSTANCE.setVisible(false); msg(c, "Плеер скрыт"); return 1; }))
                        .then(literal("show").executes(c -> { PlayerState.INSTANCE.setVisible(true); msg(c, "Плеер показан"); return 1; }))
                        .then(literal("speed")
                                .then(argument("value", FloatArgumentType.floatArg(0.25f, 4f))
                                        .executes(c -> {
                                            PlayerState.INSTANCE.setSpeed(FloatArgumentType.getFloat(c, "value"));
                                            msg(c, "Скорость x" + PlayerState.INSTANCE.speed());
                                            return 1;
                                        })))
                        .then(literal("effects").executes(c -> {
                            StringBuilder sb = new StringBuilder("Эффекты: ");
                            for (Effect e : Effect.values()) sb.append(e.id).append(" (").append(e.label).append(")  ");
                            msg(c, sb.toString());
                            msg(c, "Смена эффекта прямо в тексте: /vp play {wave}привет {glitch}мир");
                            return 1;
                        }))));
    }

    private static int play(CommandContext<FabricClientCommandSource> c, Effect effect) {
        int n = PlayerState.INSTANCE.load(StringArgumentType.getString(c, "text"), effect);
        if (n == 0) {
            c.getSource().sendError(Text.literal("Пустой текст"));
            return 0;
        }
        return 1;
    }

    private static int openGui(CommandContext<FabricClientCommandSource> c) {
        MinecraftClient client = c.getSource().getClient();
        client.send(() -> client.setScreen(new PlayerScreen()));
        return 1;
    }

    private static void msg(CommandContext<FabricClientCommandSource> c, String s) {
        c.getSource().sendFeedback(Text.literal("[Visual Player] ").formatted(Formatting.LIGHT_PURPLE)
                .append(Text.literal(s).formatted(Formatting.WHITE)));
    }
}
