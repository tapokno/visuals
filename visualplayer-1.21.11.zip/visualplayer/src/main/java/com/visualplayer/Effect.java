package com.visualplayer;

import java.util.Locale;

public enum Effect {
    TYPE("type", "Печать"),
    WAVE("wave", "Волна"),
    RAINBOW("rainbow", "Радуга"),
    SHAKE("shake", "Тряска"),
    FADE("fade", "Проявление"),
    GLITCH("glitch", "Глитч"),
    BOUNCE("bounce", "Прыжок"),
    NEON("neon", "Неон"),
    MIX("mix", "Микс");

    public final String id;
    public final String label;

    Effect(String id, String label) {
        this.id = id;
        this.label = label;
    }

    /** Эффекты, по которым крутится режим MIX (без самого MIX). */
    private static final Effect[] CYCLE = {TYPE, WAVE, RAINBOW, BOUNCE, GLITCH, FADE, NEON, SHAKE};

    public static Effect cycle(int i) {
        return CYCLE[Math.floorMod(i, CYCLE.length)];
    }

    public Effect next() {
        Effect[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public static Effect byName(String name) {
        if (name == null) return null;
        String n = name.toLowerCase(Locale.ROOT);
        for (Effect e : values()) {
            if (e.id.equals(n) || e.label.toLowerCase(Locale.ROOT).equals(n)) return e;
        }
        return null;
    }
}
